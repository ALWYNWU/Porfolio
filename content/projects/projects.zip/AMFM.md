---
date: '2017-11-01'
title: 'Apple Music Facebook Messenger Integration'
github: ''
external: 'https://www.theverge.com/2017/10/5/16433770/facebook-messenger-apple-music-bot-song-streaming'
tech:
  - Ember
  - JS
  - SCSS
company: 'Apple'
showInProjects: true
---

Facebook Messenger chat bot extension featuring authentication and full song streaming from within the Messenger app. Read more about it on [The Verge](https://www.theverge.com/2017/10/5/16433770/facebook-messenger-apple-music-bot-song-streaming).
